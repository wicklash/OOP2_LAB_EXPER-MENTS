Yusuf Eren Hoşgör - 152120211123
Safiullah Sediqi  – 152120211031