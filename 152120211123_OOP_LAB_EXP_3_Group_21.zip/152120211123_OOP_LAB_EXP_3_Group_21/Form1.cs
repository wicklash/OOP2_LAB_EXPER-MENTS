﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab03a
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        public static void Encipher(char[] input, int key, ref bool success, Label successLabel, out string encryptedMessage)
        {

            encryptedMessage = string.Empty;
            success = false;

            if (input.Length < 2)
            {
                success = false;
                successLabel.Text = "Failed";
                return;
            }

            for (int i = 0; i < input.Length; i++)
            {
                char ch = input[i];
                char encryptedchar = Cipher(ch, key);
                encryptedMessage += encryptedchar;

            }

            success = true;
            successLabel.Text = "Success";

        }

        public static char Cipher(char ch, int key)
        {
            if (!char.IsLetter(ch))
                return ch;

            char d = char.IsUpper(ch) ? 'A' : 'a';
            return (char)((((ch + key) - d) % 26) + d);
        }

        private void EncryptButton_Click(object sender, EventArgs e)
        {
            string input = passwordTextBox.Text;
            int key = 0;
            bool success = false;
            string encryptedMessage = "";


            bool containsInvalidCharacters = input.Any(c => !char.IsLetter(c) && c != ' ');

            if (containsInvalidCharacters)
            {
                MessageBox.Show("Password can only contain letters and spaces.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                passwordTextBox.Text = string.Empty;
            }
            if (caesarRadioButton.Checked)
            {
                if (string.IsNullOrWhiteSpace(caesarKeyTextBox.Text))
                {
                    key = 1;
                }
                else if (!int.TryParse(caesarKeyTextBox.Text, out key))
                {
                    MessageBox.Show("Please enter a valid integer for the Caesar Cipher key.");
                    return;
                }
            }
            else if (radioButton1.Checked)
            {
                key = 2;
            }
            else
            {
                key = 2;
            }

            if (!caesarRadioButton.Checked && !radioButton1.Checked)
            {
                MessageBox.Show("Please select an encryption method (ROT2 or Caesar Cipher).");
                return;
            }

            Encipher(input.ToCharArray(), key, ref success, successLabel, out encryptedMessage);

            if (success)
            {
                successLabel.BackColor = System.Drawing.Color.Green;
                successLabel.Visible = true;
                resultLabel.Visible = true;
                resultLabel.Text = encryptedMessage;
            }
        }

        private void caesarRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (caesarRadioButton.Checked)
            {
                caesarKeyTextBox.Visible = true;
                label2.Visible = true;
            }
            else
            {
                caesarKeyTextBox.Visible = false;
                label2.Visible = false;
            }
        }
    }   
}
