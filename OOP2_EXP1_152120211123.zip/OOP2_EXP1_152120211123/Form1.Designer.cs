﻿namespace OOP2_EXP1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            add = new Button();
            mulp = new Button();
            div = new Button();
            subs = new Button();
            label1 = new Label();
            SuspendLayout();
            // 
            // textBox1
            // 
            textBox1.Location = new Point(2, 3);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(100, 23);
            textBox1.TabIndex = 0;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(108, 3);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(100, 23);
            textBox2.TabIndex = 1;
            // 
            // add
            // 
            add.Location = new Point(2, 32);
            add.Name = "add";
            add.Size = new Size(75, 23);
            add.TabIndex = 2;
            add.Text = "addition";
            add.UseVisualStyleBackColor = true;
            add.Click += button1_Click;
            add.MouseLeave += add_MouseLeave;
            add.MouseHover += add_MouseHover;
            // 
            // mulp
            // 
            mulp.Location = new Point(164, 32);
            mulp.Name = "mulp";
            mulp.Size = new Size(75, 23);
            mulp.TabIndex = 3;
            mulp.Text = "multiplication";
            mulp.UseVisualStyleBackColor = true;
            mulp.Click += button2_Click;
            mulp.MouseLeave += mulp_MouseLeave;
            mulp.MouseHover += mulp_MouseHover;
            // 
            // div
            // 
            div.Location = new Point(245, 32);
            div.Name = "div";
            div.Size = new Size(75, 23);
            div.TabIndex = 4;
            div.Text = "division";
            div.UseVisualStyleBackColor = true;
            div.Click += div_Click;
            div.MouseLeave += div_MouseLeave;
            div.MouseHover += div_MouseHover;
            // 
            // subs
            // 
            subs.Location = new Point(83, 32);
            subs.Name = "subs";
            subs.Size = new Size(75, 23);
            subs.TabIndex = 5;
            subs.Text = "subtraction";
            subs.UseVisualStyleBackColor = true;
            subs.Click += subs_Click;
            subs.MouseLeave += subs_MouseLeave;
            subs.MouseHover += subs_MouseHover;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(228, 6);
            label1.Name = "label1";
            label1.Size = new Size(39, 15);
            label1.TabIndex = 6;
            label1.Text = "sonuç";
            label1.Click += label1_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label1);
            Controls.Add(subs);
            Controls.Add(div);
            Controls.Add(mulp);
            Controls.Add(add);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textBox1;
        private TextBox textBox2;
        private Button add;
        private Button mulp;
        private Button div;
        private Button subs;
        private Label label1;
    }
}
