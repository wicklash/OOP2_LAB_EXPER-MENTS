namespace OOP2_EXP1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

        }

        private void button1_Click(object sender, EventArgs e)
        {

            int num1, num2;
            bool isNum1Int = int.TryParse(textBox1.Text, out num1);
            bool isNum2Int = int.TryParse(textBox2.Text, out num2);

            if (isNum1Int && isNum2Int)
            {
                int toplam = num1 + num2;
                label1.Text = toplam.ToString();
                if (toplam > 0)
                {
                    label1.BackColor = Color.Green;
                }
                else
                {

                    label1.BackColor = Color.Red;
                }
            }
            else
            {
                MessageBox.Show("Please enter valid integers in both text boxes.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                label1.Text = "Error";
                label1.BackColor = SystemColors.Control;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int num1, num2;
            bool isNum1Int = int.TryParse(textBox1.Text, out num1);
            bool isNum2Int = int.TryParse(textBox2.Text, out num2);

            if (isNum1Int && isNum2Int)
            {
                int carp�m = num1 * num2;
                label1.Text = carp�m.ToString();
                if (carp�m > 0)
                {
                    label1.BackColor = Color.Green;
                }
                else
                {

                    label1.BackColor = Color.Red;
                }
            }
            else
            {
                MessageBox.Show("Please enter valid integers in both text boxes.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                label1.Text = "Error";
                label1.BackColor = SystemColors.Control;
            }
        }


        private void subs_Click(object sender, EventArgs e)
        {
            int num1, num2;
            bool isNum1Int = int.TryParse(textBox1.Text, out num1);
            bool isNum2Int = int.TryParse(textBox2.Text, out num2);

            if (isNum1Int && isNum2Int)
            {
                int fark = num1 - num2;
                label1.Text = fark.ToString();
                if (fark > 0)
                {
                    label1.BackColor = Color.Green;
                }
                else
                {

                    label1.BackColor = Color.Red;
                }
            }
            else
            {
                MessageBox.Show("Please enter valid integers in both text boxes.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                label1.Text = "Error";
                label1.BackColor = SystemColors.Control;
            }
        }

        private void div_Click(object sender, EventArgs e)
        {
            int num1, num2;
            bool isNum1Int = int.TryParse(textBox1.Text, out num1);
            bool isNum2Int = int.TryParse(textBox2.Text, out num2);

            if (isNum1Int && isNum2Int)
            {
                int b�l�m = num1 / num2;
                label1.Text = b�l�m.ToString();
                if (b�l�m > 0)
                {
                    label1.BackColor = Color.Green;
                }
                else
                {

                    label1.BackColor = Color.Red;
                }
            }
            else
            {
                MessageBox.Show("Please enter valid integers in both text boxes.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                label1.Text = "Error";
                label1.BackColor = SystemColors.Control;
            }
        }

        private void add_MouseHover(object sender, EventArgs e)
        {
            add.ForeColor = Color.Red;
        }

        private void add_MouseLeave(object sender, EventArgs e)
        {
            add.ForeColor = Color.Black;
        }

        private void subs_MouseHover(object sender, EventArgs e)
        {
            subs.ForeColor = Color.Red;
        }

        private void subs_MouseLeave(object sender, EventArgs e)
        {
            subs.ForeColor = Color.Black;
        }

        private void mulp_MouseHover(object sender, EventArgs e)
        {
            mulp.ForeColor = Color.Red;
        }

        private void mulp_MouseLeave(object sender, EventArgs e)
        {
            mulp.ForeColor = Color.Black;
        }

        private void div_MouseHover(object sender, EventArgs e)
        {
            div.ForeColor = Color.Red;
        }

        private void div_MouseLeave(object sender, EventArgs e)
        {
            div.ForeColor = Color.Black;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
